using System.Collections.Generic;

namespace AvatarRefinery.Editor.Core.Rules
{
    /// <summary>診断ルールの登録。順序はおおむね「環境 → 構造 → 見た目 → 性能」。</summary>
    public static class RuleRegistry
    {
        public static IReadOnlyList<IRule> All => _all ??= Build();
        private static List<IRule> _all;

        private static List<IRule> Build()
        {
            var list = new List<IRule>
            {
                new UnityVersionRule(),
                new SdkPresenceRule(),
#if AR_VRCSDK3_AVATARS
                new SdkVersionRule(),
                new VrcDescriptorRule(),
                new VrcExpressionConflictRule(),
                new VrcExpressionMenuRule(),
                new VrcPhysBoneRule(),
#endif
                new MissingScriptRule(),
                new LegacyDynamicBoneRule(),
                new VrmImportedStateRule(),
                new RigRule(),
                new MaterialRule(),
                new TextureRule(),
                new RenderRule(),
                new NdmfMessagesRule(),
                new PerformanceRule(),
            };
            return list;
        }
    }
}

using System.Collections.Generic;
using System.Linq;

namespace AvatarRefinery.Editor.Core.Rules
{
    /// <summary>
    /// NDMFベイク中に非破壊ツール(Modular Avatar / AAO 等)が報告したエラー・警告を診断結果に反映する。
    /// Error / InternalError → ⚠(そのままアップロードするとビルドが失敗または意図と違う結果になる)
    /// NonFatal → ℹ、Information(AAOの最適化結果など)は表示しない。
    /// </summary>
    public sealed class NdmfMessagesRule : IRule
    {
        public string Id => "ndmf.build_error";
        public bool CanRun(RuleContext ctx) => ctx.HasNdmf && (ctx.NdmfMessages.Count > 0 || !string.IsNullOrEmpty(ctx.BakeError));

        public IEnumerable<Issue> Evaluate(RuleContext ctx)
        {
            if (!string.IsNullOrEmpty(ctx.BakeError) && !ctx.BakeError.Contains("VRC Avatar Descriptor"))
            {
                // Descriptor 無しは別ルールが Blocker で扱うので、それ以外のベイク失敗のみ
                yield return new Issue("ndmf.build_error", Severity.Broken)
                {
                    TitleOverride = L10n.T("非破壊ツール(NDMF)のビルド処理が失敗しました", "The NDMF avatar build failed"),
                    Detail = ctx.BakeError,
                };
            }

            var errors = ctx.NdmfMessages.Where(m => m.Severity == "Error" || m.Severity == "InternalError").ToList();
            var warns = ctx.NdmfMessages.Where(m => m.Severity == "NonFatal").ToList();
            if (errors.Count > 0)
            {
                yield return new Issue("ndmf.build_error", Severity.Broken)
                {
                    Detail = string.Join("\n", errors.Take(8).Select(m => "- " + FirstLines(m.Message))) + (errors.Count > 8 ? "\n- …" : ""),
                }.WithMetric("count", errors.Count);
            }
            if (warns.Count > 0)
            {
                yield return new Issue("ndmf.build_warning", Severity.Info)
                {
                    Detail = string.Join("\n", warns.Take(8).Select(m => "- " + FirstLines(m.Message))) + (warns.Count > 8 ? "\n- …" : ""),
                }.WithMetric("count", warns.Count);
            }
        }

        private static string FirstLines(string s, int max = 3)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var lines = s.Replace("\r", "").Split('\n').Where(l => !string.IsNullOrWhiteSpace(l)).Take(max);
            return string.Join(" / ", lines.Select(l => l.Trim()));
        }
    }
}

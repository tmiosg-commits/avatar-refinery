using UnityEditor;
using UnityEngine;

namespace AvatarRefinery.Editor.Core
{
    public enum RefineryLanguage
    {
        Auto = 0,
        Japanese = 1,
        English = 2,
    }

    /// <summary>Shared language preference for the Lite UI, Pro UI, diagnostics, and Markdown reports.</summary>
    public static class L10n
    {
        public const string EditorPrefsKey = "AvatarRefinery.Language";

        public static RefineryLanguage Preference
        {
            get => (RefineryLanguage)EditorPrefs.GetInt(EditorPrefsKey, (int)RefineryLanguage.Auto);
            set => EditorPrefs.SetInt(EditorPrefsKey, (int)value);
        }

        public static RefineryLanguage EffectiveLanguage
        {
            get
            {
                var preference = Preference;
                if (preference != RefineryLanguage.Auto) return preference;
                // Japanese systems keep the existing Japanese experience. Other systems get English on first use.
                return Application.systemLanguage == SystemLanguage.Japanese
                    ? RefineryLanguage.Japanese
                    : RefineryLanguage.English;
            }
        }

        public static bool IsEnglish => EffectiveLanguage == RefineryLanguage.English;
        public static string T(string japanese, string english) => IsEnglish ? english : japanese;
        public static string YesNo(bool value) => value ? T("あり", "Present") : T("なし", "Not installed");

        public static string LanguageName(RefineryLanguage language)
        {
            switch (language)
            {
                case RefineryLanguage.Japanese: return "日本語";
                case RefineryLanguage.English: return "English";
                default: return "Auto";
            }
        }
    }
}

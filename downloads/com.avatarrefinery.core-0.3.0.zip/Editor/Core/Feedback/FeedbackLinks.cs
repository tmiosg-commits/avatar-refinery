using System;
using System.Collections.Generic;
using System.Text;

namespace AvatarRefinery.Editor.Core
{
    /// <summary>
    /// 要望・不具合フォーム(Google フォーム)へのリンク生成。
    /// テレメトリは行わない: ユーザーがボタンを押したときだけ、事前入力付きURLをブラウザで開く。
    /// </summary>
    public static class FeedbackLinks
    {
        public const string FormUrl = "https://docs.google.com/forms/d/e/1FAIpQLScE2Q7IN8UgO88KjfH6bPwvhwP3Wkc0ajo6aroXzEjgiCHuGg/viewform";
        public const string XSupport = "https://x.com/runsol_ai";
        public const string DistributionPage = "https://tmiosg-commits.github.io/avatar-refinery/";
        /// <summary>製品版(Avatar Refinery Pro・自動修正)の商品ページ。Lite の「製品版で自動修正」ボタンから開く。</summary>
        public const string ProductPage = "https://runsol.booth.pm/items/8737820";

        private const string EntryWantedFixes = "entry.1550352192"; // チェックボックス(自動修正の要望)
        private const string EntryRuleId = "entry.1134355279";      // 診断項目ID
        private const string EntryComment = "entry.218365569";      // 要望・不具合

        /// <summary>ルールID → フォームのチェックボックス選択肢(文言はフォームと完全一致させること)</summary>
        private static readonly Dictionary<string, string> RuleToFixOption = new Dictionary<string, string>
        {
            ["texture.uncompressed"] = "テクスチャの圧縮設定を一括変更",
            ["texture.oversized"] = "テクスチャの圧縮設定を一括変更",
            ["texture.streaming_mipmaps_off"] = "Streaming Mip Maps を一括ON",
            ["vrc.missing_script"] = "壊れたコンポーネント(Missing Script)の除去",
            ["render.anchor_override_mixed"] = "Anchor Override の統一",
            ["render.bounds_abnormal"] = "Bounds の統一",
            ["vrc.expression_params_over"] = "使っていない Expression Parameter の削除",
        };

        /// <summary>汎用の要望・不具合フォーム(事前入力なし)</summary>
        public static string General() => FormUrl;

        /// <summary>診断項目からの「自動修正が欲しい / この項目について報告」用。ルールIDと、対応する自動修正の選択肢を事前入力する。</summary>
        public static string ForIssue(string ruleId, string toolVersion = null)
        {
            var sb = new StringBuilder(FormUrl);
            sb.Append("?usp=pp_url");
            if (!string.IsNullOrEmpty(ruleId))
            {
                sb.Append('&').Append(EntryRuleId).Append('=').Append(Uri.EscapeDataString(ruleId));
                if (RuleToFixOption.TryGetValue(ruleId, out var option))
                    sb.Append('&').Append(EntryWantedFixes).Append('=').Append(Uri.EscapeDataString(option));
            }
            if (!string.IsNullOrEmpty(toolVersion))
                sb.Append('&').Append(EntryComment).Append('=').Append(Uri.EscapeDataString($"[Avatar Refinery {toolVersion}] "));
            return sb.ToString();
        }

        public static bool HasFixOption(string ruleId) => !string.IsNullOrEmpty(ruleId) && RuleToFixOption.ContainsKey(ruleId);
    }
}

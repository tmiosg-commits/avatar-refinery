# Avatar Refinery Lite(アバターリファイナリー ライト)

VRChatアバターを**アップロード前にまとめて診断**するUnityエディタ拡張です。
「何が問題で・なぜ問題で・どう直すか」を日本語で表示します。診断は**読み取り専用**で、アバターやアセットは一切変更しません。

- 対応: Unity 2022.3.22f1 / VRChat SDK Avatars 3.7.0〜3.10.x / NDMF・Modular Avatar・AAO 使用時は「ビルド後の姿」で性能を算定
- VRChat SDK が無いプロジェクトでも、ジオメトリ・マテリアル・リグの汎用診断が動きます

## 使い方

1. `Tools > Avatar Refinery > Avatar Refinery を開く`
2. Hierarchy でアバターのルートを選ぶ(自動で欄に入ります)
3. **診断する** を押す

Hierarchy のアバターを右クリック → `Avatar Refinery > このアバターを診断` でも起動できます。
結果は「⛔ アップロードを止める / ⚠ 見た目・動作が壊れる / 📉 ランクを下げている / ℹ 情報」の4段階に分かれ、各項目に **症状 → 検出 → 対応(手順)** が付きます。「詳細モード」で原因・影響・参考ページも表示されます。
「レポート保存」で Markdown ファイルに書き出せます(質問・依頼時の添付にどうぞ)。

## 診断項目(Lite)

| 分類 | 項目 |
|---|---|
| 環境 | Unity バージョン / VRChat SDK バージョン / 旧 Dynamic Bone の残存 |
| VRChat 設定 | VRC Avatar Descriptor の有無 / 視点位置 / 口パク(Viseme)/ Eye Look / Expression Parameters 容量・参照 / Expression Menu の参照切れ / FX の Write Defaults 混在 / 表情とまばたき・口パクの競合 / PhysBone の無効設定 / Missing Script |
| 非破壊ツール | NDMF(Modular Avatar / AAO 等)のビルド時エラー・警告。Expressions・Write Defaults はビルド後の状態で判定 |
| マテリアル・テクスチャ | シェーダー欠落(ピンク)/ 空スロット / 非圧縮テクスチャ / Streaming Mip Maps / 4K 以上のテクスチャ |
| リグ | Animator・Humanoid / 必須ボーン / 指ボーン |
| 描画 | Anchor Override の不統一 / Bounds 異常 / メッシュ参照切れ |
| パフォーマンス | PC・Quest 両方のランクと、各項目の「次のランクまであといくつ」 |
| VRM | VRM(VRoid 等)読み込み直後で VRChat 向け変換がまだの状態 |

## 導入

- **VCC / ALCOM**(推奨・更新が自動で届きます): https://tmiosg-commits.github.io/avatar-refinery/ の「Add to VCC / ALCOM」を押すか、Settings > Packages > Add Repository に `https://tmiosg-commits.github.io/avatar-refinery/vpm.json` を追加 → プロジェクトに「Avatar Refinery」を Install
- **unitypackage**: プロジェクトを開いた状態で unitypackage をダブルクリック → Import(`Packages/com.avatarrefinery.core` に入ります)
- 配布ページ: https://tmiosg-commits.github.io/avatar-refinery/ / 更新履歴: https://github.com/tmiosg-commits/avatar-refinery/blob/main/CHANGELOG.md

## 注意

- 診断結果の「ランク」はローカルでの推定です。実際の値は VRChat のサーバー側で最終決定され、まれに異なることがあります。
- 診断はアバターを変更しません。修正は表示された手順に沿って手動で行ってください(自動修正は製品版で提供予定)。
- MMD 由来モデルなど、利用規約上 VRChat で使えないモデルの利用を推奨するものではありません。

## サポート

- 不具合報告・要望: **X(旧Twitter)の DM** → @runsol_ai
- 対象: 本ツールの不具合・使い方。個別アバターの改変相談・他ツールの不具合は対象外です。
- レポート保存で出力した Markdown を添えていただくと、状況把握が早くなります。

## ライセンス

利用規約は `LICENSE.md` を参照してください(再配布禁止・改変私用可)。

# Avatar Refinery Lite (アバターリファイナリー ライト)

Avatar Refinery Lite is a read-only Unity Editor extension that checks VRChat avatars before upload. It explains what was found, why it matters, and what to do next in English or Japanese, and can export the result as Markdown.

VRChatアバターを**アップロード前にまとめて診断**するUnityエディタ拡張です。「何が問題で・なぜ問題で・どう直すか」を日本語・英語で表示します。診断は**読み取り専用**で、アバターやアセットは一切変更しません。

- 対応: Unity 2022.3.22f1 / VRChat SDK Avatars 3.9.x〜3.10.x (3.10.4 で検証) / NDMF・Modular Avatar・AAO 使用時は「ビルド後の姿」で性能を算定
- VRChat SDK が無いプロジェクトでも、ジオメトリ・マテリアル・リグの汎用診断が動きます

## 使い方

1. `Tools > Avatar Refinery > Open Avatar Refinery`
2. Hierarchy でアバターのルートを選ぶ(自動で欄に入ります)
3. ツールバーで **Auto / 日本語 / English** を選び、**診断する / Check Avatar** を押す

Hierarchy のアバターを右クリック → `Avatar Refinery > Check This Avatar` でも起動できます。
結果は「⛔ アップロードを止める / ⚠ 見た目・動作が壊れる / 📉 ランクを下げている / ℹ 情報」の4段階に分かれ、各項目に **症状 → 検出 → 対応(手順)** が付きます。「詳細モード」で原因・影響・参考ページも表示されます。
「レポート保存」で Markdown ファイルに書き出せます(質問・依頼時の添付にどうぞ)。

## Console のエラー解説 / Console Errors (0.4.0〜)

`Tools > Avatar Refinery > Console Errors (エラーの解説)`、または Avatar Refinery の画面の **エラーを確認 / Console のエラー** ボタンで開きます。

- Unity の Console(または Editor.log)に出ているエラーを読み、**対処が必要 / 確認 / 未登録 / 無視してよい** に仕分けます
- 各エラーに **どんなときに出る → 原因 → 直し方** を表示します(VRChat の改変でよく出る32種類)。大量に出るシェーダー変種やライセンス通信のお知らせは「無視してよい」にまとめ、既定では畳みます
- 辞書にないエラーは、Unity と主なパッケージの版を添えた **質問用の文** としてコピーできます(ユーザー名の入ったパスは伏せます)
- 参照を持たない独立したアセンブリに入っているため、VRChat SDK・NDMF・自分のスクリプトがコンパイルできない状態でも動きます。**エラーが出る前に** Avatar Refinery を入れておいてください(エラーが出てから入れたスクリプトは、Unity の仕組みで読み込まれません)
- 説明は目安です。直す前にプロジェクトのバックアップを取ってください

The Console Errors window reads the Unity Console (or Editor.log), sorts errors into **Fix / Check / Not in dictionary / Safe to ignore**, and explains when each appears, its cause, and how to fix it (32 common VRChat-project errors). Unknown errors can be copied as a question with version details, with user paths masked. It lives in a reference-free assembly, so it keeps working when the SDK, NDMF, or your scripts fail to compile—install Avatar Refinery before the error appears.

## 診断項目(Lite)

| 分類 | 項目 |
|---|---|
| 環境 | Unity バージョン / VRChat SDK バージョン / 旧 Dynamic Bone の残存 |
| VRChat 設定 | VRC Avatar Descriptor の有無 / 視点位置 / 口パク(Viseme)/ Eye Look / Expression Parameters 容量・参照 / Expression Menu の参照切れ / FX の Write Defaults 混在 / 表情とまばたき・口パクの競合 / PhysBone の無効設定 / Missing Script |
| 非破壊ツール | NDMF(Modular Avatar / AAO 等)のビルド時エラー・警告。Expressions・Write Defaults はビルド後の状態で判定 |
| マテリアル・テクスチャ | シェーダー欠落(ピンク)/ 空スロット / 非圧縮テクスチャ / Streaming Mip Maps / 4K 以上のテクスチャ |
| リグ | Animator・Humanoid / 必須ボーン / 指ボーン |
| 描画 | Anchor Override の不統一 / Bounds 異常 / メッシュ参照切れ |
| パフォーマンス | PC・Quest 両方のランクと、各項目の「次のランクまであといくつ」 |
| VRM | VRM(VRoid 等)読み込み直後で VRChat 向け変換がまだの状態 |

## 導入

- **VCC / ALCOM**(推奨・更新が自動で届きます): https://tmiosg-commits.github.io/avatar-refinery/ の「Add to VCC / ALCOM」を押すか、Settings > Packages > Add Repository に `https://tmiosg-commits.github.io/avatar-refinery/vpm.json` を追加 → プロジェクトに「Avatar Refinery」を Install
- **unitypackage**: プロジェクトを開いた状態で unitypackage をダブルクリック → Import(`Packages/com.avatarrefinery.core` に入ります)
- 配布ページ: https://tmiosg-commits.github.io/avatar-refinery/ / 更新履歴: https://github.com/tmiosg-commits/avatar-refinery/blob/main/CHANGELOG.md

## 注意

- 診断結果の「ランク」はローカルでの推定です。実際の値は VRChat のサーバー側で最終決定され、まれに異なることがあります。
- 診断はアバターを変更しません。修正は表示された手順に沿って手動で行ってください。ワンクリックの自動修正(プレビュー・自動バックアップ・すべて元に戻す 付き)は製品版 **Avatar Refinery Pro** で提供しています: https://runsol.booth.pm/items/8737820
- MMD 由来モデルなど、利用規約上 VRChat で使えないモデルの利用を推奨するものではありません。

## サポート

- 不具合報告・要望: **要望・不具合フォーム**(匿名可・Googleログイン不要) https://docs.google.com/forms/d/e/1FAIpQLScE2Q7IN8UgO88KjfH6bPwvhwP3Wkc0ajo6aroXzEjgiCHuGg/viewform または **X(旧Twitter)の DM** → @runsol_ai
- ツール内の「この項目を報告」「不具合・要望を送る」ボタンからも同じフォームが開きます(項目IDが自動入力されます。自動送信はしません)
- 対象: 本ツールの不具合・使い方。個別アバターの改変相談・他ツールの不具合は対象外です。
- レポート保存で出力した Markdown を添えていただくと、状況把握が早くなります。

## ライセンス

利用規約は `LICENSE.md` を参照してください(再配布禁止・改変私用可)。

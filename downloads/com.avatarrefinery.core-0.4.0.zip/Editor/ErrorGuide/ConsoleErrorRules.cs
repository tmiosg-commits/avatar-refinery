using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace AvatarRefinery.ErrorGuide
{
    public enum ErrorLevel { Fix, Check, Ignore, Unknown }

    [Serializable]
    public class ConsoleErrorRule
    {
        public string id;
        public string severity;
        public string title, title_en;
        public string when, when_en;
        public string cause, cause_en;
        public string[] fix, fix_en;
        public string[] patterns;
        public string[] samples;

        [NonSerialized] public Regex[] Compiled;

        public ErrorLevel Level
        {
            get
            {
                switch (severity)
                {
                    case "fix": return ErrorLevel.Fix;
                    case "check": return ErrorLevel.Check;
                    case "ignore": return ErrorLevel.Ignore;
                    default: return ErrorLevel.Unknown;
                }
            }
        }

        public string Title => Pick(title, title_en);
        public string When => Pick(when, when_en);
        public string Cause => Pick(cause, cause_en);
        public string[] Fix => ErrorGuideText.IsEnglish && fix_en != null && fix_en.Length > 0 ? fix_en : fix;

        static string Pick(string ja, string en) => ErrorGuideText.IsEnglish && !string.IsNullOrEmpty(en) ? en : ja;
    }

    [Serializable]
    public class ConsoleErrorRuleFile
    {
        public string version;
        public ConsoleErrorRule[] rules;
    }

    /// <summary>エラー辞書の読み込みと照合。上から順に見て、最初に当たったルールを返す。</summary>
    public class ConsoleErrorRules
    {
        public const string RulesFileName = "ArConsoleErrorRules";

        public string Version { get; private set; }
        public IReadOnlyList<ConsoleErrorRule> Rules => _rules;
        readonly List<ConsoleErrorRule> _rules = new List<ConsoleErrorRule>();

        public static ConsoleErrorRules LoadFromProject()
        {
            var guid = AssetDatabase.FindAssets(RulesFileName + " t:TextAsset").FirstOrDefault();
            if (guid == null) throw new FileNotFoundException("Error dictionary not found: " + RulesFileName + ".json");
            var asset = AssetDatabase.LoadAssetAtPath<TextAsset>(AssetDatabase.GUIDToAssetPath(guid));
            return FromJson(asset.text);
        }

        public static ConsoleErrorRules FromJson(string json)
        {
            var file = JsonUtility.FromJson<ConsoleErrorRuleFile>(json);
            var result = new ConsoleErrorRules { Version = file.version };
            foreach (var rule in file.rules ?? Array.Empty<ConsoleErrorRule>())
            {
                rule.Compiled = (rule.patterns ?? Array.Empty<string>())
                    .Select(p => new Regex(p, RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.CultureInvariant))
                    .ToArray();
                result._rules.Add(rule);
            }
            return result;
        }

        public ConsoleErrorRule Match(string message)
        {
            if (string.IsNullOrEmpty(message)) return null;
            foreach (var rule in _rules)
                foreach (var rx in rule.Compiled)
                    if (rx.IsMatch(message)) return rule;
            return null;
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace AvatarRefinery.ErrorGuide
{
    public enum EntryKind { Error, Warning }

    public class ConsoleItem
    {
        public string Message;
        public EntryKind Kind;
        public int Count = 1;
    }

    /// <summary>Console に今出ている内容と、Editor.log を読む。</summary>
    public static class ConsoleReader
    {
        // UnityEditor.LogEntry.mode のビット（Unity 2022.3 の内部定義）
        const int ErrorMask = 1 | 2 | 16 | 64 | 256 | 2048 | 8192 | 131072 | 1048576 | 2097152 | 4194304;
        const int WarningMask = 128 | 512 | 4096;

        /// <summary>Console の中身を読む。内部 API なので、読めない版の Unity では例外を投げる。</summary>
        public static List<ConsoleItem> ReadConsole(bool includeWarnings)
        {
            var asm = typeof(EditorWindow).Assembly;
            var entries = asm.GetType("UnityEditor.LogEntries");
            var entryType = asm.GetType("UnityEditor.LogEntry");
            if (entries == null || entryType == null)
                throw new NotSupportedException("この Unity の版では Console の内容を読めません。「Editor.log から読む」を使ってください。");

            const BindingFlags F = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            var start = entries.GetMethod("StartGettingEntries", F);
            var end = entries.GetMethod("EndGettingEntries", F);
            var get = entries.GetMethod("GetEntryInternal", F);
            var messageField = entryType.GetField("message", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            var modeField = entryType.GetField("mode", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (start == null || end == null || get == null || messageField == null || modeField == null)
                throw new NotSupportedException("この Unity の版では Console の内容を読めません。「Editor.log から読む」を使ってください。");

            var items = new List<ConsoleItem>();
            var entry = Activator.CreateInstance(entryType);
            int count = (int)start.Invoke(null, null);
            try
            {
                for (int i = 0; i < count; i++)
                {
                    get.Invoke(null, new object[] { i, entry });
                    int mode = (int)modeField.GetValue(entry);
                    var message = (string)messageField.GetValue(entry);
                    if ((mode & ErrorMask) != 0) items.Add(new ConsoleItem { Message = message, Kind = EntryKind.Error });
                    else if (includeWarnings && (mode & WarningMask) != 0) items.Add(new ConsoleItem { Message = message, Kind = EntryKind.Warning });
                }
            }
            finally
            {
                end.Invoke(null, null);
            }
            return Collapse(items);
        }

        public static string EditorLogPath()
        {
            if (Application.platform == RuntimePlatform.WindowsEditor)
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Unity", "Editor", "Editor.log");
            if (Application.platform == RuntimePlatform.OSXEditor)
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "Library", "Logs", "Unity", "Editor.log");
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), ".config", "unity3d", "Editor.log");
        }

        static readonly Regex LogPick = new Regex(@"(error|exception|failed|warning|missing|not found|can't be found|could not)", RegexOptions.IgnoreCase);
        static readonly Regex LogSkip = new Regex(@"^\s*(at |UnityEngine\.|UnityEditor\.|System\.|VRC\.|Cysharp|\(Filename|Start importing|\[\d+/\d+|Starting: |\s+LogAssemblyErrors|Processed pass|Rebuilding DAG|.*\(at [^)]*:\d+\)\s*$)");
        static readonly Regex WarnLike = new Regex(@"(warning|WARNING)");

        /// <summary>Editor.log から、エラー・警告らしい行を拾う。Console が消えた後の確認用。</summary>
        public static List<ConsoleItem> ReadEditorLog(string path, bool includeWarnings, int maxLines = 200000)
        {
            var items = new List<ConsoleItem>();
            if (!File.Exists(path)) return items;
            // Unity が書き込み中でも読めるように共有モードで開く
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            using (var reader = new StreamReader(fs, Encoding.UTF8))
            {
                string line;
                int n = 0;
                while ((line = reader.ReadLine()) != null && n++ < maxLines)
                {
                    if (line.Length < 12 || !LogPick.IsMatch(line) || LogSkip.IsMatch(line)) continue;
                    var kind = WarnLike.IsMatch(line) && !line.Contains("error") ? EntryKind.Warning : EntryKind.Error;
                    if (kind == EntryKind.Warning && !includeWarnings) continue;
                    items.Add(new ConsoleItem { Message = line, Kind = kind });
                }
            }
            return Collapse(items);
        }

        /// <summary>同じ文面（数字の違いは無視）をまとめて件数にする。</summary>
        public static List<ConsoleItem> Collapse(List<ConsoleItem> items)
        {
            var map = new Dictionary<string, ConsoleItem>();
            var order = new List<ConsoleItem>();
            foreach (var it in items)
            {
                var key = Normalize(it.Message);
                if (map.TryGetValue(key, out var existing)) { existing.Count++; continue; }
                map[key] = it;
                order.Add(it);
            }
            return order;
        }

        static readonly Regex Digits = new Regex(@"[0-9a-fA-F]{8,}|\d+");

        public static string Normalize(string message)
        {
            var first = (message ?? "").Split('\n')[0];
            return Digits.Replace(first, "#");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace AvatarRefinery.ErrorGuide
{
    /// <summary>
    /// Avatar Refinery 本体と同じ言語設定（EditorPrefs "AvatarRefinery.Language"）を読む。
    /// 本体の asmdef（VRChat SDK・NDMF を参照）に依存させないため、ここに最小限を持つ。
    /// </summary>
    public static class ErrorGuideText
    {
        const string LanguageKey = "AvatarRefinery.Language"; // 0=Auto 1=日本語 2=English

        public static bool IsEnglish
        {
            get
            {
                var pref = EditorPrefs.GetInt(LanguageKey, 0);
                if (pref == 1) return false;
                if (pref == 2) return true;
                return Application.systemLanguage != SystemLanguage.Japanese;
            }
        }

        public static string T(string japanese, string english) => IsEnglish ? english : japanese;

        /// <summary>
        /// 本体の UiText.Wrap と同じ処理（本体の asmdef を参照しないため写して持つ）。
        /// Unity IMGUI は半角スペースだけを改行位置とみなし、日本語の連続を1語として扱う。
        /// 日本語に隣り合う半角スペースを取り除き、英単語だけが行末に孤立する折り返しを防ぐ。
        /// </summary>
        public static string Wrap(string s)
        {
            if (string.IsNullOrEmpty(s) || s.IndexOf(' ') < 0) return s;
            var sb = new StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == ' ')
                {
                    bool prevCjk = i > 0 && IsCjk(s[i - 1]);
                    bool nextCjk = i + 1 < s.Length && IsCjk(s[i + 1]);
                    bool lineStart = i == 0 || s[i - 1] == '\n' || (i > 0 && s[i - 1] == ' ' && (i == 1 || s[i - 2] == '\n'));
                    if ((prevCjk || nextCjk) && !lineStart) continue;
                }
                sb.Append(c);
            }
            return sb.ToString();
        }

        // 行頭に来てはいけない文字（閉じ括弧・句読点など）と、行末に残してはいけない文字（開き括弧）
        const string NoLineStart = "）」』】〕〉》、。，．・：；？！ーぁぃぅぇぉっゃゅょゎァィゥェォッャュョヮヵヶ)]},.:;!?%";
        const string NoLineEnd = "（「『【〔〈《([{";

        /// <summary>
        /// 実際の文字幅を測りながら改行を入れる。Unity IMGUI は日本語の連続を1語として扱い、
        /// 収まらないと英単語の途中でも切るため、改行位置をこちらで決める。
        /// 日本語は1文字ずつ改行可・英単語は途中で切らない・開き括弧は行末に、閉じ括弧や句読点は行頭に置かない・
        /// 「1.」のような番号は次の語と離さない。日本語の文中の英語の語句（Modular Avatar など）は、
        /// 幅の半分に収まる限り語と語の間でも切らない。
        /// </summary>
        public static string WrapToWidth(string s, Func<string, float> measure, float width)
        {
            if (string.IsNullOrEmpty(s) || measure == null || width < 1f) return s;
            var outText = new StringBuilder(s.Length + 16);
            var paragraphs = s.Split('\n');
            for (int p = 0; p < paragraphs.Length; p++)
            {
                if (p > 0) outText.Append('\n');
                var tokens = Tokenize(paragraphs[p]);
                if (paragraphs[p].Any(IsCjk)) tokens = KeepLatinPhrases(tokens, measure, width / 2f);
                var line = new List<string>();
                foreach (var raw in tokens)
                {
                    var t = raw;
                    if (line.Count > 0 && t.Length > 0 && measure((string.Concat(line) + t).TrimEnd()) > width)
                    {
                        if (NoLineStart.IndexOf(t[0]) < 0)
                        {
                            outText.Append(string.Concat(line).TrimEnd()).Append('\n');
                            line.Clear();
                            t = t.TrimStart();
                        }
                        else
                        {
                            // 行頭に置けない文字は、直前の単位ごと次の行へ送る（行末にぶら下げてはみ出さない）
                            int keep = line.Count - 1;
                            while (keep > 0 && NoLineStart.IndexOf(line[keep][0]) >= 0) keep--;
                            if (keep > 0)
                            {
                                outText.Append(string.Concat(line.GetRange(0, keep)).TrimEnd()).Append('\n');
                                var carried = line.GetRange(keep, line.Count - keep);
                                carried[0] = carried[0].TrimStart();
                                line = carried;
                            }
                        }
                    }
                    line.Add(t);
                }
                outText.Append(string.Concat(line).TrimEnd());
            }
            return outText.ToString();
        }

        /// <summary>改行してよい単位に区切る（日本語は1文字、英数字は語＋後ろの空白、開き括弧と番号は次とつなぐ）。</summary>
        static List<string> Tokenize(string s)
        {
            var raw = new List<string>();
            int i = 0;
            while (i < s.Length)
            {
                char c = s[i];
                if (IsCjk(c) || NoLineEnd.IndexOf(c) >= 0 || NoLineStart.IndexOf(c) >= 0)
                {
                    int j = i + 1;
                    while (j < s.Length && s[j] == ' ') j++;
                    raw.Add(s.Substring(i, j - i));
                    i = j;
                    continue;
                }
                int k = i;
                while (k < s.Length && s[k] != ' ' && !IsCjk(s[k]) && NoLineEnd.IndexOf(s[k]) < 0 && NoLineStart.IndexOf(s[k]) < 0) k++;
                while (k < s.Length && s[k] == ' ') k++;
                if (k == i) k = i + 1;
                raw.Add(s.Substring(i, k - i));
                i = k;
            }
            // 開き括弧・番号（"1." など）は次の単位とつなぐ
            var merged = new List<string>();
            for (int n = 0; n < raw.Count; n++)
            {
                var t = raw[n];
                while (n + 1 < raw.Count && EndsWithJoiner(t))
                    t += raw[++n];
                merged.Add(t);
            }
            return merged;
        }

        /// <summary>日本語の文中で続く英単語（"Modular " + "Avatar"）を1つの単位にまとめる。maxWidth を超える長さにはしない。</summary>
        static List<string> KeepLatinPhrases(List<string> tokens, Func<string, float> measure, float maxWidth)
        {
            var merged = new List<string>();
            foreach (var t in tokens)
            {
                int last = merged.Count - 1;
                if (last >= 0 && t.Length > 0 && IsLatinWordChar(t[0])
                    && merged[last].EndsWith(" ") && IsLatinWordChar(merged[last].TrimEnd().LastOrDefault())
                    && measure((merged[last] + t).TrimEnd()) <= maxWidth)
                    merged[last] += t;
                else
                    merged.Add(t);
            }
            return merged;
        }

        static bool IsLatinWordChar(char c)
        {
            return c < 0x80 && char.IsLetterOrDigit(c);
        }

        static bool EndsWithJoiner(string t)
        {
            var x = t.TrimEnd();
            return x.Length > 0 && (NoLineEnd.IndexOf(x[x.Length - 1]) >= 0 || IsListNumber(x));
        }

        static bool IsListNumber(string t)
        {
            var x = t.Trim();
            if (x.Length < 2 || x[x.Length - 1] != '.') return false;
            for (int i = 0; i < x.Length - 1; i++) if (!char.IsDigit(x[i])) return false;
            return true;
        }

        public static bool IsCjk(char c)
        {
            return (c >= 0x3000 && c <= 0x30FF)
                || (c >= 0x4E00 && c <= 0x9FFF)
                || (c >= 0xFF00 && c <= 0xFFEF)
                || (c >= 0x3400 && c <= 0x4DBF);
        }
    }
}

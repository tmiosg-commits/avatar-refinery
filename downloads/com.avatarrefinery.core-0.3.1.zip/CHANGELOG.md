# Changelog

## 0.3.1 (2026-09-27)

- Replaced the draft Lite terms with standalone Japanese and English terms of use. No diagnostic or UI behavior changed.
- Lite のドラフト利用規約を正式な日英併記の利用規約に改めました。診断・UI の動作変更はありません。

## 0.3.0 (2026-08-29)

- Added full English UI and English Markdown report output for all current diagnostic rules.
- Added **Auto / 日本語 / English** language selection while preserving Japanese as the automatic choice on Japanese systems.
- Added English knowledge-base guidance for symptoms, causes, impact, and corrective steps.
- Added automated coverage that checks every English knowledge entry and English report headings for Japanese-text leakage.
- Updated the supported SDK range to 3.9.x–3.10.x and verified the release with Unity 2022.3.22f1 / VRChat SDK 3.10.4.

- 全診断ルールの英語UIと英語Markdownレポートに対応しました。
- **Auto / 日本語 / English** の言語切り替えを追加し、日本語OSでAutoを選んだ場合は従来どおり日本語表示になります。
- 対応SDK範囲を3.9.x〜3.10.xに更新し、Unity 2022.3.22f1 / VRChat SDK 3.10.4で検証しました。

## 0.2.0 (2026-08-19)

- 追加: 製品版(Avatar Refinery Pro・自動修正)を同じウィンドウに差し込むための拡張点。Pro を入れると各項目に「修正する…」、サマリに「まとめて修正」、フッターに「すべて元に戻す」が現れます(Lite 単体の動作は変わりません)
- 追加: 修正後の再診断で前回の結果を保持(Before/After 表示用)
- 変更: 自動修正できる項目のボタンを「自動修正が欲しい」→「**製品版で自動修正**」に(製品版の商品ページが開きます)。不具合・要望フォームはフッターの「不具合・要望を送る」と各項目の「この項目を報告」から引き続き使えます
- 変更: ウィンドウ幅が 520px 未満のとき、ツールバーを 2 段にして操作が欠けないように
- 変更: 非圧縮テクスチャの判定で、プラットフォーム上書きの明示フォーマット(RGBA32 等)も非圧縮として扱うように
- 変更: 上記以外に、診断ロジックの変更はありません

## 0.1.2 (2026-08-17)

- 追加: 各診断項目に「自動修正が欲しい」/「この項目を報告」ボタン。押すと要望・不具合フォーム(匿名可・Googleログイン不要)がブラウザで開き、項目IDが自動入力されます(自動送信はしません)
- 追加: 診断結果に「自動修正で直せる可能性: N件(製品版で対応予定)」の表示
- 追加: フッターに「不具合・要望を送る」「使い方・更新情報」ボタン
- 変更: 動作に影響する診断ロジックの変更はありません

## 0.1.1 (2026-08 初回公開 / β)

初回公開版(Lite)。

- 診断: 環境 / VRChat 設定(Descriptor・視点位置・Viseme・Eye Look・Expressions・Write Defaults・Missing Script)/ マテリアル・テクスチャ / リグ / 描画 / パフォーマンス(PC・Quest)/ VRM 未変換状態
- 診断: 表情アニメーションとまばたき / 口パクの競合(半目・白目・口が動かない)。Tracking Control(Animation)付きのステートは除外
- 診断: Expression Menu の参照切れ(サブメニュー未設定・存在しないパラメータ・項目数超過)
- 診断: PhysBone の無効設定(Root がアバター外・揺れる対象なし・空参照・重なり)
- NDMF(Modular Avatar / AAO 等)使用時は「ビルド後の姿」で性能を算定。Expression Parameters 容量・Menu / Parameters 参照・Write Defaults 混在もビルド後の状態で判定
- NDMF のビルド時エラー・警告を診断結果に反映(NDMF コンソールは自動表示しない)
- 日本語の説明(症状 → 検出 → 原因 → 影響 → 対応)、初心者モード / 詳細モード
- Markdown レポート出力
- 読み取り専用(アバター・アセットを変更しない)

(0.1.0 は内部検証版。公開せず 0.1.1 に統合)
